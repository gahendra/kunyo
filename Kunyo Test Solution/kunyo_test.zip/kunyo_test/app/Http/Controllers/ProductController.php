<?php

  namespace App\Http\Controllers;

  use App\Models\Product;
  use Illuminate\Http\Request;
  use DB;
  use Carbon\Carbon;
  use DateTime;
  use Session;

  class ProductController extends Controller
  {
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      $products = Product::latest()->paginate(5);

      return view('products.index', compact('products'), ['currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency])
        ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      return view('products.create', ['currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $system_selected_currency = Session::get('sel_currency');
      $is_price_dollar = ($system_selected_currency == 'USD')?TRUE:FALSE;

      $request->validate([
        'name' => 'required',
        'description' => 'required',
        'price' => 'required',
      ]);

      $request_all = $request->all();
      $request_all['price'] = self::get_currency_price_value($request_all['price'], $is_price_dollar, FALSE);
      Product::create($request_all);

      return redirect()->route('products.index')
        ->with('success', 'Product created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      $product->test_var = 'yohoh';
      return view('products.show', compact('product'), ['currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');
      
      return view('products.edit', compact('product'), ['currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\product $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
      $system_selected_currency = Session::get('sel_currency');
      $is_price_dollar = ($system_selected_currency == 'USD')?TRUE:FALSE;

      $request->validate([
        'name' => 'required',
        'description' => 'required',
        'price' => 'required',
      ]);
      $request_all = $request->all();
      $request_all['price'] = self::get_currency_price_value($request_all['price'], $is_price_dollar, FALSE);
      
      $product->update($request_all);

      return redirect()->route('products.index')
        ->with('success', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
      $product->delete();

      return redirect()->route('products.index')
        ->with('success', 'Product deleted successfully');
    }

    /***
     * Place Order
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function place_order()
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      $products = DB::table('products')
        ->select('products.id', 'products.name', 'products.price')
        ->get();

      $current_reward_points = self::get_user_reward_point(1);
      $current_reward_points = self::get_currency_price_value($current_reward_points, TRUE, FALSE);

      $vars = ['products' => $products, 'current_reward_points' => $current_reward_points, 'currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency];
      return view('products.order', $vars);
    }

    /**
     * Place Order submit
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function place_order_submit(Request $request)
    {
      $system_selected_currency = Session::get('sel_currency');
      $is_price_dollar = ($system_selected_currency == 'USD')?TRUE:FALSE;

      $current_date_time = Carbon::now()->toDateTimeString();

      $request_all = $request->all();

      $product_ids = isset($request_all['product_id']) ? $request_all['product_id'] : [];
      $atotal = self::get_currency_price_value($request_all['atotal_price'], $is_price_dollar, FALSE);
      $total = self::get_currency_price_value($request_all['total_price'], $is_price_dollar, FALSE);

      if (!empty($product_ids)) {

        // Add order
        $data = [
          'user_id' => 1,
          'total_price' => $atotal,
          'redeemed_price' => $total,
          'order_status' => 0,
          'created_at' => $current_date_time,
          'updated_at' => $current_date_time,
        ];

        $order_id = DB::table('product_order')->insertGetId($data);

        // Add order details
        foreach ($product_ids as $item) {
          $tmp = explode('--', $item);
          $id = $tmp[0];
          $price = self::get_currency_price_value($tmp[1], $is_price_dollar, FALSE);

          $data = [
            'order_id' => $order_id,
            'product_id' => $id,
            'price' => $price,
          ];

          DB::table('product_order_detail')->insertGetId($data);
        }

        // Adjust remaining reward if Reward point is redeemed
        if ($atotal != $total) {
          $current_reward_points = self::get_user_reward_point(1);
          DB::table('user_rewards')->where('user_id', '=', 1)->delete();

          $used_point = $atotal - $total;

          $reward_points = $current_reward_points - $used_point;

          if ($reward_points < 0) {
            $reward_points = 0;
          }

          // Expiry date One Year from now
          $expiry_date_time = Carbon::now()->addYear();

          $data = [
            'user_id' => 1,
            'reward_points' => $reward_points,
            'created_at' => $current_date_time,
            'updated_at' => $current_date_time,
            'expiry_date' => $expiry_date_time,
          ];

          DB::table('user_rewards')->insertGetId($data);
        }

        return redirect()->route('place-order')
          ->with('success', 'Order Placed Successfully !');
      } else {
        return redirect()->route('place-order')
          ->with('error', 'Please select a Product to place order !');
      }
    }

    /**
     * Order List
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function order_list()
    {
      global $product_order_status, $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      $orders = DB::table('product_order AS po')
        ->join('users AS u', 'po.user_id', '=', 'u.id')
        ->select('po.*', 'u.name')
        ->get();

      $vars = ['orders' => $orders, 'order_status' => $product_order_status, 'currencies' => $system_currencies, 'system_selected_currency' => $system_selected_currency];
      return view('products.order-list', $vars);
    }

    /**
     * Order Statys
     * @param $order_id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function order_status_form($order_id)
    {
      global $product_order_status;

      $order_details = DB::table('product_order AS po')
        ->select('po.order_status')
        ->where('po.id', '=', $order_id)
        ->get()->first();

      $order_status = $order_details->order_status;

      $vars = ['order_id' => $order_id, 'order_status' => $order_status, 'product_order_status' => $product_order_status];
      return view('products.order-status', $vars);
    }

    /**
     * Change order status
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function order_status_form_submit(Request $request)
    {
      $request_all = $request->all();
      $order_id = $request_all['order_id'];
      $order_status = $request_all['new_status'];

      $data = [
        'order_status' => $order_status
      ];
      DB::table('product_order')
        ->where('id', $order_id)
        ->update($data);

      // Adding reward point
      if ($order_status == 2) {
        $current_date_time = Carbon::now()->toDateTimeString();

        $order_details = DB::table('product_order AS po')
          ->select('po.total_price')
          ->where('po.id', '=', $order_id)
          ->get()->first();

        // Converting points to currency
        $total_price = $order_details->total_price * 0.01; //1 point equivalent to USD $0.01

        $current_reward_points = self::get_user_reward_point(1);

        $reward_points = $total_price + $current_reward_points;

        DB::table('user_rewards')->where('user_id', '=', 1)->delete();

        // Expiry date One Year from now
        $expiry_date_time = Carbon::now()->addYear();
        $data = [
          'user_id' => 1,
          'reward_points' => $reward_points,
          'created_at' => $current_date_time,
          'updated_at' => $current_date_time,
          'expiry_date' => $expiry_date_time,
        ];

        DB::table('user_rewards')->insertGetId($data);
      }

      return redirect()->route('order-list')
        ->with('success', 'Order Status Changed !');
    }

    /***
     * Get User Reward
     * @param $user_id
     * @return int
     */
    public function get_user_reward_point($user_id)
    {
      $today = Carbon::createFromFormat('d/m/Y', date('d/m/Y'));

      $user_reward_details = DB::table('user_rewards AS ur')
        ->select('ur.reward_points')
        ->where('ur.user_id', $user_id)
        ->where('ur.expiry_date', '>=', $today) // Only active reward
        ->first();

      $current_reward_points = (!empty($user_reward_details)) ? $user_reward_details->reward_points : 0;

      return $current_reward_points;
    }

    /**
     * MYSQL Query for sales amount
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function sales_query()
    {

      $sales_query = 'SELECT COUNT(DISTINCT o.`Order_ID`) as Number_Of_Order,
                      SUM(CASE 
                          WHEN o.`Sales_Type` = "Normal" 
                          THEN op.`Normal_price` 
                          ELSE 0 
                      END) AS Total_Sales_Amount_Normal,
                      SUM(CASE 
                          WHEN o.`Sales_Type` = "Promotion" 
                          THEN op.`Promotion_price` 
                          ELSE 0 
                      END) AS Total_Sales_Amount_Promotion
                      FROM `orders` AS o
                      INNER JOIN `orders_products` AS op
                      ON o.`Order_ID` =  op.`Order_ID`;';


      $vars = ['sales_query' => $sales_query];

      return view('products.sales-query', $vars);
    }

    /**
     * GST calculation
     * Order  total MYR5.00 has included 6% GST, what is the actual amount of GST in MYR for this  Order?
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function gst_calculation()
    {

      /*
        Let X be the Amount before GST
        Mathematically,
          X + 6% of X = 5
          From this equation we can get X = (5*100)/106
       */

      $gst_exclusive_amt = round((5*100)/106, 2);
      $gst_amt = round($gst_exclusive_amt * 0.06, 2);
      $total_amount = $gst_amt + $gst_exclusive_amt;

      $vars = ['gst_exclusive_amt' => $gst_exclusive_amt, 'gst_amt' => $gst_amt, 'total_amount' => $total_amount];

      return view('products.gst-calculation', $vars);
    }

    /***
     * Set currency
     * @param $code
     * @return \Illuminate\Http\RedirectResponse
     */
    public function change_currency($code)
    {
      $destination = url()->previous();

      session(['sel_currency' => $code]);
      return redirect($destination);
    }

    /***
     * Convert Currency Value
     * @param $price
     * @return string
     */
    public static function get_currency_price_value($price, $is_price_dollar = TRUE, $symbol = TRUE)
    {
      global $system_currencies;
      $system_selected_currency = Session::get('sel_currency');

      if($is_price_dollar){
        $new_price = round($price * $system_currencies[$system_selected_currency]['value'], 2);
      }
      else{
        $new_price = round($price / $system_currencies[$system_selected_currency]['value'], 2);
      }

      if($symbol){
        $new_price = $system_currencies[$system_selected_currency]['symbol'] . $new_price;
      }

      return $new_price;
    }

  }
