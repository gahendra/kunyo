<?php

  namespace App\Providers;

  use Illuminate\Support\ServiceProvider;
  use Illuminate\Support\Facades\Schema;
  use Session;

  class AppServiceProvider extends ServiceProvider
  {
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
      //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
      Schema::defaultStringLength(191);

      global $product_order_status, $system_currencies;

      $product_order_status = [
        0 => 'Pending',
        1 => 'Processing',
        2 => 'Completed',
      ];

      $system_currencies = [
        'USD' => [
          'title' => 'Dollar',
          'symbol' => '$',
          'value' => 1,
        ],
        'EUR' => [
          'title' => 'Euro',
          'symbol' => '€',
          'value' => 0.85,
        ],
        'GBP' => [
          'title' => 'Pound',
          'symbol' => '£',
          'value' => 0.73,
        ],
      ];

      // Set default currency
      $currency = Session::get('sel_currency');
      if ($currency == '') {
        session(['sel_currency' => 'USD']);
      }
    }
  }
