<?php

  use Illuminate\Database\Migrations\Migration;
  use Illuminate\Database\Schema\Blueprint;
  use Illuminate\Support\Facades\Schema;

  class CreateProductOrder extends Migration
  {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::create('product_order', function (Blueprint $table) {
        $table->bigIncrements('id');
        $table->bigInteger('user_id')->default(0);
        $table->decimal('total_price', 22)->nullable()->default(0.00);
        $table->decimal('redeemed_price', 22)->nullable()->default(0.00);
        $table->tinyInteger('order_status')->default(0);
        $table->timestamps();
      });

      Schema::create('product_order_detail', function (Blueprint $table) {
        $table->bigIncrements('id');
        $table->bigInteger('order_id')->default(0);
        $table->bigInteger('product_id')->default(0);
        $table->decimal('price', 22)->nullable()->default(0.00);
      });

      Schema::create('user_rewards', function (Blueprint $table) {
        $table->bigIncrements('id');
        $table->bigInteger('user_id')->default(0);
        $table->decimal('reward_points', 22)->nullable()->default(0.00);
        $table->timestamps();
        $table->timestamp('expiry_date', 0)->nullable();
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
      Schema::dropIfExists('product_order');
      Schema::dropIfExists('product_order_detail');
      Schema::dropIfExists('user_rewards');
    }
  }
