var gtotal_price = 0;
var has_used_points = false;

$(document).ready(function () {

    check_total_price();

    $('.product-ids').change(function () {
        check_total_price();
    });

    $('#use_points').click(function (){

        if(!has_used_points) {
            has_used_points = true;
            var reward_points = parseFloat($('#reward_points').val());
            var redeemed_point = 0;
            if (gtotal_price >= reward_points) {
                redeemed_point = gtotal_price - reward_points;
            }

            gtotal_price = redeemed_point;
            $('#total_pricce').text('$' + redeemed_point);
            $('#total_price').val(redeemed_point);

            $('#has_used_points').val(1);
        }
    });


    function check_total_price() {
        has_used_points = false;
        $('#has_used_points').val(0);

        var total_price = 0;
        $(".product-ids").each(function (index) {

            var that = jQuery(this);
            if (that.is(':checked')) {
                var price = parseFloat(that.attr('data-price'));
                total_price += price;
            }

        });

        gtotal_price = total_price;
        $('#total_pricce').text('$'+total_price);
        $('#total_price').val(total_price);
        $('#atotal_price').val(total_price);
    }
});