@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Order List</h2>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    @if ($message = Session::get('error'))
        <div class="alert alert-danger">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="alert alert-info">
        <p>Note: Please click on Status to change it</p>
    </div>

    <form action="{{route('place_order_submit')}}" method="POST">
        @csrf
        <table class="table table-bordered table-responsive-lg">
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Total Price</th>
                <th>Redeemed Price</th>
                <th>Status</th>
            </tr>
            @foreach ($orders as $order)
                <tr>
                    <td>{{$order->id}}</td>
                    <td>{{$order->name}}</td>
                    <td>${{$order->total_price}}</td>
                    <td>${{$order->redeemed_price}}</td>
                    <td>
                        <a href="{{'order-status/'.$order->id}}">
                            {{$order_status[$order->order_status]}}
                        </a>
                    </td>
                </tr>
            @endforeach
        </table>
    </form>

@endsection
