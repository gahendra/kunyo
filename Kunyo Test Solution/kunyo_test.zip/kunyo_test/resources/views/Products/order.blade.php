@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Place Order</h2>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    @if ($message = Session::get('error'))
        <div class="alert alert-danger">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="alert alert-info">
        <p>Please select Items to place your order</p>
    </div>


    <div class="pull-right">
        <div class="alert alert-info">
            <p>Note: Points should be used at last only <br> Clicking on checkbox will reset the points</p>
        </div>
        <p>
            Reward Points: {{$current_reward_points}}
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="#" id="use_points" class="btn btn-primary btn-danger">Use Points</a>
        </p>
    </div>

    <form action="{{route('place_order_submit')}}" method="POST">
        @csrf
        <table class="table table-bordered table-responsive-lg">
            <tr>
                <th></th>
                <th>Name</th>
                <th>Price</th>
            </tr>
            @foreach ($products as $product)
                <tr>
                    <td><input type="checkbox" class="product-ids" data-price="{{$product->price}}" name="product_id[]"
                               value="{{$product->id.'--'.$product->price}}"></td>
                    <td>{{$product->name}}</td>
                    <td>${{$product->price}}</td>
                </tr>
            @endforeach

            <tr>
                <td colspan="2" align="center"><strong>Total Order Price</strong></td>
                <td>
                    <span id="total_pricce"></span>
                    <input type="hidden" name="atotal_price" id="atotal_price" value="">
                    <input type="hidden" name="total_price" id="total_price" value="">
                    <input type="hidden" name="has_used_points" id="has_used_points" value="0">
                    <input type="hidden" name="reward_points" id="reward_points" value="{{$current_reward_points}}">
                </td>
            </tr>
        </table>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Confirm Order</button>
        </div>
    </form>

@endsection
