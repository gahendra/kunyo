Hello <b>{{ $name }}</b>,
<p>{{body}}</p>