@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Welcome to Kunyo Test Solution</h2>
            </div>
        </div>
    </div>

    <div class="container">
        <h2 class="mt-5">Question 1: Visualize Solution and PHP Coding</h2>
        <p class="lead">
            1. Flowchart or UML diagram on the reward system
        </p>
        <p>
            <a href="{{url('kunyo-test-uml.PNG')}}" target="_blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Click here to view UML
                Diagram</a>
        </p>

        <p class="lead">
            2. Design MySQL database schema for this reward system
        </p>
        <p>
            <a href="{{url('kunyo-test-schema.PNG')}}" target="_blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Click here to view
                Schema</a>
        </p>

        <p class="lead">
            3. PHP functions to credit user reward points after order completion
        </p>
        <p>
        <ul>
            <li>To credit the reward points after order completion, we can use this system.</li>
            <li>
                Customer have to place order first.
                Click <a href="{{url('place-order')}}" target="_blank">here</a> to place order.
            </li>
            <li>
                Once order is placed, it is listed in the Order List page.
                Click <a href="{{url('order-list')}}" target="_blank">here</a> to go to Order List. <br>
                The order status can be changed by clicking the Status link
            </li>
            <li>
                When the status is changed to Completed, the user gets the reward points. <br>
                The reward points is converted as per the requirement so that it can be easily redeemed later.
            </li>
            <li>
                The customer can redeem the reward points while placing order.
            </li>
            <li>
                The code and funtions can be found in following files:
                <ul>
                    <li>Routes: <code>routes/web.php</code></li>
                    <li>Functions: <code>app/Http/Controllers/ProductController.php</code></li>
                    <li>Theme files are inside the folder: <code>resources/views/Products</code></li>
                </ul>
            </li>
        </ul>
        </p>
        <p>
        <div class="alert alert-danger">
            <p>Note: Currently this system is for single user only and no login is required for now.</p>
        </div>
        </p>


        <h2 class="mt-5">Question 2: MySQL Query</h2>
        <p>
            <a href="{{url('sales-query')}}" target="_blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Click here to view MySQL
                Query</a>
        </p>

        <h2 class="mt-5">Question 3 : Calculation</h2>
        <p>
            <a href="{{url('gst-calculation')}}" target="_blank">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Click here to view
                Calculation and its result</a>
        </p>

        <br><br><br>
    </div>

@endsection
