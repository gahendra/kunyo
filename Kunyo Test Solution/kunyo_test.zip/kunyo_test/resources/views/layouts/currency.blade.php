<div class="dropdown">
    <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
        Currency
    </a>

    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
      <?php foreach($currencies as $code => $currency){?>
        <li>
            <a class="dropdown-item <?php echo ($system_selected_currency == $code)?'active':'';?>" href="{{url('change-currency/'.$code)}}">
                {{$currency['title'].'('.$currency['symbol'].')'}}
            </a>
        </li>
      <?php }?>
    </ul>
</div>