@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Question 3 : Calculation</h2>
            </div>
        </div>
    </div>
    <blockquote class="blockquote">
        Order  total MYR5.00 has included 6% GST, what is the actual amount of GST in MYR for this
        Order?
    </blockquote>

    <code class="">
        <h4>Solution:</h4>
        Let X be the Amount before GST. <br>
        So mathematically, <br>
        X + 6% of X = 5, <br>
        From this equation we can get X = (5*100)/106 = 4.72
    </code>


    <br><br>
    <p class="">
        Therefore the required data from the calculation are as follows:
        <ul>
            <li>Amount before GST: {{$gst_exclusive_amt}}</li>
            <li>GST Amount: {{$gst_amt}}</li>
            <li>Total Amount: {{$total_amount}}</li>
        </ul>
    </p>

@endsection
