<?php use App\Http\Controllers\ProductController?>
@extends('layouts.app')

@section('content')

    <div class="dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Currency
        </a>

        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <?php foreach($currencies as $code => $currency){?>
            <li>
                <a class="dropdown-item <?php echo ($system_selected_currency == $code)?'active':'';?>" href="{{url('change-currency/'.$code)}}">
                    {{$currency['title'].'('.$currency['symbol'].')'}}
                </a>
            </li>
          <?php }?>
        </ul>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Order List</h2>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    @if ($message = Session::get('error'))
        <div class="alert alert-danger">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="alert alert-info">
        <p>Note: Please click on Status to change it</p>
    </div>

    <form action="{{route('place_order_submit')}}" method="POST">
        @csrf
        <table class="table table-bordered table-responsive-lg">
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Total Price</th>
                <th>Redeemed Price</th>
                <th>Status</th>
            </tr>
            @foreach ($orders as $order)
                <tr>
                    <td>{{$order->id}}</td>
                    <td>{{$order->name}}</td>
                    <td>{{ProductController::get_currency_price_value($order->total_price, TRUE, TRUE)}}</td>
                    <td>{{ProductController::get_currency_price_value($order->redeemed_price, TRUE, TRUE)}}</td>
                    <td>
                        <a href="{{'order-status/'.$order->id}}">
                            {{$order_status[$order->order_status]}}
                        </a>
                    </td>
                </tr>
            @endforeach
        </table>
    </form>

@endsection
