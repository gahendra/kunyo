@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Question 2: MySQL Query
                </h2>
            </div>
        </div>
    </div>

    <blockquote class="blockquote">
        Based on the given tables, write a SINGLE query to retrieve the total order and sales amount of
        all the orders. Your output should display Number_Of_Order, Total_Sales_Amount
    </blockquote>
    <blockquote class="blockquote">
        NOTE: Refer Normal_Price if Sales_Type is 'Normal'
        Refer Promotion_Price if Sales_Type is 'Promotion'
    </blockquote>

    <code class="">
        <h4>Solution:</h4>
        <p class="mb-0">{{$sales_query}}</p>
    </code>


@endsection
