<?php

  use Illuminate\Support\Facades\Route;
  use App\Http\Controllers\ProductController;
  use App\Http\Controllers\UserController;

  /*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
  */

  // Home page
  Route::get('/', function () {
    return view('index');
  });

  // Product Listing
  Route::resource('products', ProductController::class);

  // Order placement
  Route::get('place-order', [ProductController::class, 'place_order'])->name('place-order');
  Route::post('place-order/submit', [ProductController::class, 'place_order_submit'])->name('place_order_submit');

  // Order list
  Route::get('order-list', [ProductController::class, 'order_list'])->name('order-list');

  // Order status update
  Route::get('order-status/{id}', [ProductController::class, 'order_status_form'])->name('order-status');
  Route::post('order-status/submit', [ProductController::class, 'order_status_form_submit'])->name('order_status_form_submit');

  // Requested MYSQL Query for the sales
  Route::get('sales-query', [ProductController::class, 'sales_query'])->name('sales-query');

  // GST Calculation solution
  Route::get('gst-calculation', [ProductController::class, 'gst_calculation'])->name('gst-calculation');
