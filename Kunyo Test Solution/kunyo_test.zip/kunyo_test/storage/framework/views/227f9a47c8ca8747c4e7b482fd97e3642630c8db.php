<?php use \App\Http\Controllers\ProductController?>


<?php $__env->startSection('content'); ?>

    <div class="dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Currency
        </a>

        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <?php foreach($currencies as $code => $currency){?>
            <li>
                <a class="dropdown-item <?php echo ($system_selected_currency == $code)?'active':'';?>" href="<?php echo e(url('change-currency/'.$code)); ?>">
                    <?php echo e($currency['title'].'('.$currency['symbol'].')'); ?>

                </a>
            </li>
          <?php }?>
        </ul>
    </div>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Place Order</h2>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="alert alert-info">
        <p>Please select Items to place your order</p>
    </div>


    <div class="pull-right">
        <div class="alert alert-info">
            <p>Note: Points should be used at last only <br> Clicking on checkbox will reset the points</p>
        </div>
        <p>
            Reward Points: <?php echo e($current_reward_points); ?>

            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="#" id="use_points" class="btn btn-primary btn-danger">Use Points</a>
        </p>
    </div>

    <form action="<?php echo e(route('place_order_submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered table-responsive-lg">
            <tr>
                <th></th>
                <th>Name</th>
                <th>Price</th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $price = ProductController::get_currency_price_value($product->price, TRUE);
                    $price_num = ProductController::get_currency_price_value($product->price, TRUE, FALSE);
                ?>
                <tr>
                    <td><input type="checkbox" class="product-ids" data-price="<?php echo e($price_num); ?>" name="product_id[]"
                               value="<?php echo e($product->id.'--'.$price_num); ?>"></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td colspan="2" align="center"><strong>Total Order Price</strong></td>
                <td>
                    <span id="total_pricce"></span>
                    <input type="hidden" name="atotal_price" id="atotal_price" value="">
                    <input type="hidden" name="total_price" id="total_price" value="">
                    <input type="hidden" name="has_used_points" id="has_used_points" value="0">
                    <input type="hidden" name="reward_points" id="reward_points" value="<?php echo e($current_reward_points); ?>">
                </td>
            </tr>
        </table>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Confirm Order</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kunyo_test\resources\views/products/order.blade.php ENDPATH**/ ?>