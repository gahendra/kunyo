<?php use App\Http\Controllers\ProductController?>


<?php $__env->startSection('content'); ?>

    <div class="dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Currency
        </a>

        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <?php foreach($currencies as $code => $currency){?>
            <li>
                <a class="dropdown-item <?php echo ($system_selected_currency == $code)?'active':'';?>" href="<?php echo e(url('change-currency/'.$code)); ?>">
                    <?php echo e($currency['title'].'('.$currency['symbol'].')'); ?>

                </a>
            </li>
          <?php }?>
        </ul>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Order List</h2>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="alert alert-info">
        <p>Note: Please click on Status to change it</p>
    </div>

    <form action="<?php echo e(route('place_order_submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered table-responsive-lg">
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Total Price</th>
                <th>Redeemed Price</th>
                <th>Status</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->name); ?></td>
                    <td><?php echo e(ProductController::get_currency_price_value($order->total_price, TRUE, TRUE)); ?></td>
                    <td><?php echo e(ProductController::get_currency_price_value($order->redeemed_price, TRUE, TRUE)); ?></td>
                    <td>
                        <a href="<?php echo e('order-status/'.$order->id); ?>">
                            <?php echo e($order_status[$order->order_status]); ?>

                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kunyo_test\resources\views/products/order-list.blade.php ENDPATH**/ ?>