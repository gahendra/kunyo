<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Change Order Status</h2>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($order_status == 2) {?>
    <div class="alert alert-info">
        <p>Note: Status cannot be changed now as the Order is Completed</p>
    </div>
    <?php } ?>

    <form action="<?php echo e(route('order_status_form_submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="col-xs-12 col-sm-12 col-md-4 text-center">
            <select name="new_status" class="form-control">
              <?php foreach ($product_order_status as $key => $item) { ?>
                    <option value="<?php echo e($key); ?>" <?php echo ($key == $order_status)?'selected="selected"':'';?>>
                        <?php echo e($item); ?>

                    </option>
              <?php } ?>
            </select>
        </div>

        <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">

        <br><br>
        <?php if($order_status < 2) {?>
        <div class="col-xs-12 col-sm-12 col-md-4 text-center">
            <button type="submit" class="btn btn-primary">Change Status</button>
        </div>
        <?php } ?>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kunyo_test\resources\views/products/order-status.blade.php ENDPATH**/ ?>