<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Question 3 : Calculation</h2>
            </div>
        </div>
    </div>
    <blockquote class="blockquote">
        Order  total MYR5.00 has included 6% GST, what is the actual amount of GST in MYR for this
        Order?
    </blockquote>

    <code class="">
        <h4>Solution:</h4>
        Let X be the Amount before GST. <br>
        So mathematically, <br>
        X + 6% of X = 5, <br>
        From this equation we can get X = (5*100)/106 = 4.72
    </code>


    <br><br>
    <p class="">
        Therefore the required data from the calculation are as follows:
        <ul>
            <li>Amount before GST: <?php echo e($gst_exclusive_amt); ?></li>
            <li>GST Amount: <?php echo e($gst_amt); ?></li>
            <li>Total Amount: <?php echo e($total_amount); ?></li>
        </ul>
    </p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kunyo_test\resources\views/products/gst-calculation.blade.php ENDPATH**/ ?>